1. Right Click Project, Add> Add Generated Items
2. Consume Adapter Service (From left hand column)
3. Choose sqlBinding
4. Click "Configure" button
5. Set SQL Server, database and credentials 
6. Click Ok
7. Click Connect
8. Browse to the table or stored proc that you want to use.
9. Add it to the schema.
10. It supports more than one, but keep it simple and just add one at a time.
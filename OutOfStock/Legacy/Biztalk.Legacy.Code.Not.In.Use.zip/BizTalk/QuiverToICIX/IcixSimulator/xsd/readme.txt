1.  edit the xml file to look the way you want it to be.
2.  open the file in Visual Studio, and select XML > Create Schema from the menu
3.  Save the generated .xsd file to same folder.
4.  Open the Visual Studio command prompt from the start menu
	Start Menu --> Microsoft Visual Studio 2010 --> Visual Studio Tools --> Visual Studio 2010 Command Prompt
5.  CD to the xsd directory
6. run ServiceUtil.bat
7. This generates the .cs file that defines the Data Contract for the service.

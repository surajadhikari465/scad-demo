﻿using OOSCommon;

namespace OOS.Model
{
    public interface ILogService
    {
        IOOSLog GetLogger();
        
    }
}

﻿namespace MockingFrameworksCompare.BrainSample
{
    public class Iron
    {
        public bool IsHot { get; set; }
    }
}
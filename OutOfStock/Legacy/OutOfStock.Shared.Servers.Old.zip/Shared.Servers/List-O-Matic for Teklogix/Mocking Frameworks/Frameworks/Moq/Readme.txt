- To skip verification for Moq assembly:

sn -Vr *,69f491c39445e920
The full version of Stubs is available for download at http://research.microsoft.com/stubs.

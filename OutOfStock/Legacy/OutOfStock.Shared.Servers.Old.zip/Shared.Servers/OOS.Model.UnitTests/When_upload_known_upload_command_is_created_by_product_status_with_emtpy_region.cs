﻿using System;
using System.Linq;
using Magnum.TestFramework;

namespace OOS.Model.UnitTests
{
    //[Scenario]
    //public class When_upload_known_upload_command_is_created_by_product_status_with_emtpy_region : Given_a_product_status_to_known_upload_command_mapper
    //{
    //    protected override ProductStatus[] When()
    //    {
    //        var statusInVendorRegion1 = CreateProductStatusInVendorRegion();
    //        return new[] {statusInVendorRegion1};
    //    }

    //    private ProductStatus CreateProductStatusInVendorRegion()
    //    {
    //        var region = string.Empty;
    //        var vendorKey = "UNF";
    //        var upc = "0008819470070";
    //        var vin = "26352";
    //        var status = "";
    //        var expiration = Convert.ToDateTime("10/11/12");

    //        return new ProductStatus(region, vendorKey, vin, upc, string.Empty, DateTime.MinValue, status, expiration);
    //    }

    //    [Then]
    //    public void No_command_is_created()
    //    {
    //        commands.Count().ShouldEqual(0);
    //    }

    //}
}

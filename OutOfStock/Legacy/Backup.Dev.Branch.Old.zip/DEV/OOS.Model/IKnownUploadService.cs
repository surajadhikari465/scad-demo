﻿using OOSCommon;

namespace OOS.Model
{
    public interface IKnownUploadService
    {
        bool Upload(IKnownUpload knownUpload);
    }
}

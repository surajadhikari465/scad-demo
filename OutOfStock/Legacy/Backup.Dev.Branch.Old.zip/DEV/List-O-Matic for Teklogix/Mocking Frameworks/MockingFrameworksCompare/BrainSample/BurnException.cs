﻿using System;

namespace MockingFrameworksCompare.BrainSample
{
    /// <summary>
    /// An exception that gets thrown if a hand touches a hot iron.
    /// </summary>
    public class BurnException : Exception
    {
    }
}
